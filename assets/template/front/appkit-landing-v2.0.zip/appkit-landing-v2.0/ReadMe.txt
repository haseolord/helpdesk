Free Bootstrap Theme for Developers & Startups

Theme name:
=======================================================================
Appkit Landing

Theme version:
=======================================================================
v2.0

Release Date:
=======================================================================
19 July 2018

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media (http://themes.3rdwavemedia.com/)

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Twitter: @3rdwave_themes

License: 
=======================================================================
This template is free under the Creative Commons Attribution 3.0 License.
https://creativecommons.org/licenses/by/3.0/
